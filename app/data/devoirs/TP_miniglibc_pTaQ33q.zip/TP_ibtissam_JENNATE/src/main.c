#include "mini_lib.h"
#include "stdio.h"
#include <string.h>
#include <stdlib.h>

int main(int argc , char ** argv) {

      char* buffer ;
   char * str = "welcome";
   mini_printf(str);
   printf("\n");
   
   //mini_scanf(buffer, 5);
  char buff [500];

    int nbre =mini_strcpy(str,buff);
    printf("le nombre de car copiés est %d\n", nbre);
    

   int *buffe;

   buffe= mini_calloc( sizeof( int ),10 );
   if( buffe != NULL )
      printf( "memory Allocated \n" );
   else
      printf( "Can't allocate memory\n" );
    for(int i =0; i<10; ++i) {
        buffe[i] = i+1;
        printf("%d, ", buffe[i]);
    
    }
    printf("\n");

   mini_free( buffe);


    MYFILE* file = mini_fopen("file_open.txt", 'r');
    char *b = mini_calloc(1, 1000);
    mini_fread(b, 4, 200, file);
    mini_printf(b);

    mini_fwrite(b, 2, 300, file);

    MYFILE * out_file;
    
    out_file = mini_fopen("file_open.txt", 'r');
    if ( out_file == NULL ) {
        mini_printf( "Cannot open file \n");
        mini_exit( -1 );
    }
    
 
    mini_fputc( out_file ,'\n');
    
    mini_fclose( out_file );
        
    return 0;
 


}
