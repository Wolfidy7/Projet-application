#include <stdio.h>
#include "mini_lib.h"
#include <fcntl.h>

int main(int argc, char **argv)
{
    if (argc < 2)
    {
        mini_printf("le nbre d'args insuffisant ");
        mini_exit();
    }
    else if (argc > 2)
    {
        mini_printf("vous avez saisez trop d'arguments");
        mini_exit();
    }
    else
    {
        open(argv[1], O_CREAT | O_TRUNC);
        mini_exit();
    }
}