#include <stdio.h>
#include "mini_lib.h"

int main(int argc, char** argv) {
    for(int i=0; i<argc; ++i) {
	fputs(argv[i], stdout);
	printf("\n");
    }
    if (argc < 3) {
        mini_printf("To few arguments");
        mini_exit();
    }  else if (argc > 3) {
        mini_printf("To many arguments");
        mini_exit();
    }
    MYFILE *src = mini_fopen(argv[1], 'r');
    MYFILE *dst = mini_fopen(argv[2], 'w');
    char *buffer = (char*)mini_calloc(1, IOBUFFER_SIZE);
    int r = mini_fread(buffer, 1, IOBUFFER_SIZE, src);
    mini_fwrite(buffer, 1, r, dst);
    mini_exit();
}
