#include <stdio.h>
#include "mini_lib.h"

int main(int argc, char **argv)
{
    if (argc < 2)
    {
        mini_printf("le nbre d'args insuffisant");
        mini_exit();
    }
    else if (argc > 2)
    {
        mini_printf("vous avez saisez trop d'arguments");
        mini_exit();
    }
    else
    {
        MYFILE *file = mini_fopen(argv[1], 'r');
        char *b = mini_calloc(1, IOBUFFER_SIZE);
        int r = mini_fread(b, 1, IOBUFFER_SIZE, file);
        int j = 0;
        for (int i = 0; i < r; ++i)
        {
            if ((b[i] == ' ') || (b[i] == '\n') || (b[i] == '\0'))
            {
                if ((b[i - 1] != ' ') && (b[i - 1] != '\n') || (b[i - 1] != '\0'))
                    j++;
            }
        }
        int ma = j;
        int n = 0;
        while (ma != 0)
        {
            ma = (ma - (ma % 10)) / 10;
            n += 1;
        }
        char *str = (char *)mini_calloc(1, n + 1);
        str[n] = '\0';
        for (int i = 0; i < n; ++i)
        {
            str[n - 1 - i] = j % 10 + 48;
            j = (j - (j % 10)) / 10;
        }
        printf("%s", str);
        mini_printf(str);
        mini_exit();
    }
}
