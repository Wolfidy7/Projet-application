#include "mini_lib.h"
#include <unistd.h>
#include <errno.h>
#include <stdio.h>

struct malloc_element *malloc_list = NULL;
struct file_element *file_list = NULL;

void *mini_calloc(int taille, int nb_el)
{

    intptr_t size = taille * nb_el;
    struct malloc_element *temp = malloc_list;
    while (temp != NULL)
    {
        if ((temp->size > size) && (temp->statut == 0))
        {
            temp->statut = 1;
            return temp->ptr;
        }
        else
        {
            temp = temp->next_malloc;
            continue;
        }
    }

   
     void *ptr = sbrk(size);
    if (ptr == (void *)-1)
    {
        return NULL;
    }
    for (int i = 0; i < size; ++i)
    {
        ((char *)ptr)[i] = '\0';
    }

    struct malloc_element *new_elem = (struct malloc_element *)sbrk(sizeof(struct malloc_element));
    new_elem->ptr = ptr;
    new_elem->size = size;
    new_elem->statut = 1;

    struct malloc_element *temp_p = malloc_list;
    new_elem->next_malloc = temp_p;
    malloc_list = new_elem;

    return ptr;
}

void mini_free(void *ptr)
{
    struct malloc_element *temp = malloc_list;
    while (temp != NULL)
    {
        if (temp->ptr == ptr)
        {
            temp->statut = 0;
            return;
        }
        else
        {
            temp = temp->next_malloc;
        }
    }
    return;
}

void mini_exit()
{
    write(1, buffer, ind);
    while (file_list != NULL)
    {
        mini_fflush(file_list->file);
        file_list = file_list->next;
    }
    _exit(0);
}
