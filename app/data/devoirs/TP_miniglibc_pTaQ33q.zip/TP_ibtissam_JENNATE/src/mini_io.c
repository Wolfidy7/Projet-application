#include "mini_lib.h"
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

MYFILE* mini_fopen(char* file, char mode) {
    MYFILE* new_open_file = (MYFILE*)mini_calloc(sizeof(MYFILE), 1);
    switch (mode)
    {
    case 'r':
        new_open_file->fd = open(file, O_RDONLY);
        break;
    case 'w':
        new_open_file->fd = open(file, O_WRONLY);
        break;
    case 'b':
        new_open_file->fd = open(file, O_RDWR);
        break;
    case 'a':
        new_open_file->fd = open(file, O_APPEND);
        break;
    }
    if (new_open_file->fd == -1) {
        mini_perror("Error code: ");
        return NULL;
    } 
    new_open_file->ind_read = -1;
    new_open_file->ind_write = -1;
    struct file_element *new_file_element = (struct file_element *)mini_calloc(sizeof(struct file_element), 1);
    new_file_element->file = new_open_file;
    new_file_element->next = file_list;
    file_list = new_file_element;
    return new_open_file;
}

int mini_fread(void* buffer, int size_element, int number_element, MYFILE* file) {
    if (file->ind_read == -1) {
        file->buffer_read = (char*)mini_calloc(1, IOBUFFER_SIZE);
        file->ind_read = 0;
    }    
    ssize_t n;
    int count = 0;
    while ((n = read(file->fd, file->buffer_read, IOBUFFER_SIZE))) {
        for(int i= file->ind_read; i<n; ++i) {
            ((char*)buffer)[count] = ((char*)(file->buffer_read))[i];
            count ++;
            file->ind_read += 1;
            if (count == number_element) {
                return number_element;
            }
        }
    }
    return count/size_element;
}

int mini_fwrite(void* buffer, int size_element, int number_element, MYFILE* file) {
    if (file->ind_write == -1) {
        file->buffer_write = (char*)mini_calloc(1, IOBUFFER_SIZE);
        file->ind_write = 0;
    }
    
    int count = 0;
    while (count < size_element*number_element) {
        ((char*)(file->buffer_write))[file->ind_write] = ((char*)buffer)[count];
        count ++;
        file->ind_write += 1;
        
        if (file->ind_write == IOBUFFER_SIZE) {
            break;
        }
    }
    write(file->fd, &(((char*)(file->buffer_write))[file->ind_write - count]), count);
    file->ind_write -= count;
    return count/size_element;
}

int mini_fflush(MYFILE* file) {
    int w = write(file->fd, file->buffer_write, file->ind_write);
    file->ind_write = 0;
    return w;
}

int mini_fclose(MYFILE* file) {
    int c = close(file->fd);
    mini_free(file->buffer_read);
    file->ind_read = -1;
    mini_free(file->buffer_write);
    file->ind_write = -1;
    struct file_element *temp = file_list;
    while (temp != NULL) {
        if (file_list->file == file) {
            file_list = file_list->next;
            break;
        }
        if (temp->next->file == file) {
            temp->next =temp->next->next;
            break;
        } 
    }
    return c;
}

int mini_fgetc(MYFILE* file) {
    char* buffer = (char*)mini_calloc(1, 2);
    buffer[1] = '\0';
    if (mini_fread(buffer,1, 1, file) != 1) {
        return -1;
    } else {
        return buffer[0];
    }
}

int mini_fputc(MYFILE *file, char c) {
    char *buffer = (char*)mini_calloc(1, 2);
    buffer[0] = c;
    buffer[1] = '\0';
    if (mini_fwrite(buffer, 1, 1, file) != 1) {
        return -1;
    } else {
        return c;
    }
}