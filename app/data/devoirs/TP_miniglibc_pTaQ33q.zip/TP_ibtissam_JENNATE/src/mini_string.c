#include "mini_lib.h"
#include <unistd.h>
#include <string.h>
#include <errno.h>

int ind = -1;
char *buffer = NULL;
void mini_printf(char *str)
{
    if (ind == -1)
    {
        buffer = (char *)mini_calloc(1, 1024);
        ind = 0;
    }
    char *temp = str;
    int old_ind = ind;
    while ((*temp != '\n') && (*temp != '\0'))
    {
        buffer[ind] = *temp;
        temp += 1;
        ind += 1;
        continue;
    }
    if (*temp == '\n')
    {
        buffer[ind] = '\n';
        ind += 1;
        write(1, &(buffer[old_ind]), ind);
        ind = old_ind;
    }
}

int mini_scanf(char *buffer, int size_buffer)
{
    ssize_t n = read(0, buffer, size_buffer - 1);
    if (n == -1)
        return -1;
    buffer[n] = '\0';
    return n;
}

int mini_strlen(char *s)
{
    int i = 0;
    while (s[i] != '\0')
    {
        i += 1;
    }
    return i;
}

int mini_strcpy(char *s, char *d)
{
    int i = 0;
    while ((s[i] != '\0') && (d[i] != '\0'))
    {
        d[i] = s[i];
        i += 1;
    }
    return i;
}

int mini_strcmp(char *s1, char *s2)
{
    int i = 0;
    while ((s1[i] != '\0') && (s2[i] != '\0'))
    {
        if (s1[i] > s2[i])
        {
            return 1;
        }
        else if (s1[i] < s2[i])
        {
            return -1;
        }
        else
        {
            continue;
        }
    }
    if (s1[i] != '\0')
        return 1;
    if (s2[i] != '\0')
        return -1;
    return 0;
}

void mini_perror(char *message)
{
    mini_printf(message);
    int temp = errno;
    int i;
    char *buffer;
    if (errno < 10)
    {
        buffer = (char *)mini_calloc(sizeof(char), 2);
        i = 0;
    }
    else if (errno < 100)
    {
        buffer = (char *)mini_calloc(sizeof(char), 3);
        i = 1;
    }
    else
    {
        buffer = (char *)mini_calloc(sizeof(char), 4);
        i = 2;
    }
    while (temp != 0)
    {
        buffer[i] = (temp % 10) + 48;
        --i;
        temp = (temp - temp % 10) / 10;
    }
    mini_printf(buffer);
    return;
}
