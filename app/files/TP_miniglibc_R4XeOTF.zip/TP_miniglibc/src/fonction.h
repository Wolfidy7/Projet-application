#ifndef MINI_LIB_H
#define MINI_LIB_H
// Déclaration de la fonction addition
int addition(int a, int b);

// Déclaration de la fonction factoriel
int factoriel(int n);

// Déclaration de la fonction division
float division(float a, float b);

#endif