#include "fonction.h"

// Implémentation de la fonction division
float division(float a, float b) {
    return a / b;
}